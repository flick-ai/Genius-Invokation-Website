from genius_invocation.card.action.equipment.talent.import_head import *
from genius_invocation.card.character.characters.Mona import * 

class ProphecyofSubmersion(TalentCard):
    id: int = 212031
    name: str = "Prophecy of Submersion"
    name_ch = "沉没的预言"
    is_action = True
    cost = [{'cost_num': 3, 'cost_type': 1}]
    cost_power = 3
    character = Mona
    def __init__(self) -> None:
        super().__init__()
        